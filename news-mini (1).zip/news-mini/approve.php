
<?php
require_once 'config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("UPDATE articles SET approved=1 WHERE id=?");
$stmt->execute([$id]);
header("Location: index.php"); exit;
?>
