
<?php
require_once 'config.php';
$rows = $pdo->query("SELECT * FROM articles ORDER BY id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="sq">
<head>
<meta charset="UTF-8">
<title>Mini CMS - Lajmet</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h1>📋 Mini CMS - Lajmet</h1>
<a href="add.php"><button>Shto Lajm</button></a>

<table>
<tr>
  <th>ID</th>
  <th>Titulli</th>
  <th>Autori</th>
  <th>Status</th>
  <th>Veprime</th>
</tr>
<?php foreach($rows as $r): ?>
<tr>
  <td><?= (int)$r['id'] ?></td>
  <td><?= htmlspecialchars($r['title']) ?></td>
  <td><?= htmlspecialchars($r['author']) ?></td>
  <td class="status"><?= $r['approved'] ? "✅ Aprovuar" : "❌ Në pritje" ?></td>
  <td>
    <a href="edit.php?id=<?= (int)$r['id'] ?>">✏️ Edit</a> |
    <a href="approve.php?id=<?= (int)$r['id'] ?>">✔️ Approve</a> |
    <a href="delete.php?id=<?= (int)$r['id'] ?>" onclick="return confirm('Fshi lajmin?')">🗑️ Delete</a>
  </td>
</tr>
<?php endforeach; ?>
<?php if (count($rows)===0): ?>
<tr><td colspan="5">S'ka lajme ende. Shto të parin!</td></tr>
<?php endif; ?>
</table>
</div>
</body>
</html>
