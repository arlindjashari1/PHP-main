
<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $author = trim($_POST['author'] ?? '');

    if ($title !== '' && $content !== '' && $author !== '') {
        $stmt = $pdo->prepare("INSERT INTO articles (title, content, author) VALUES (?, ?, ?)");
        $stmt->execute([$title, $content, $author]);
        header("Location: index.php"); exit;
    } else {
        $error = "Të gjitha fushat janë të detyrueshme.";
    }
}
?>
<!DOCTYPE html>
<html lang="sq">
<head>
<meta charset="UTF-8">
<title>Shto Lajm</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Shto Lajm të Ri</h2>
<?php if (!empty($error)): ?><div style="color:#b91c1c;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
<label>Titulli:</label>
<input type="text" name="title" required>

<label>Përmbajtja:</label>
<textarea name="content" rows="5" required></textarea>

<label>Autori:</label>
<input type="text" name="author" required>

<input type="submit" value="Ruaj">
</form>
<a href="index.php">⬅️ Kthehu</a>
</div>
</body>
</html>
