
<?php
require_once 'config.php';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$article = $pdo->prepare("SELECT * FROM articles WHERE id=?");
$article->execute([$id]);
$r = $article->fetch();
if (!$r) { die('Artikulli nuk u gjet.'); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $author = trim($_POST['author'] ?? '');

    if ($title !== '' && $content !== '' && $author !== '') {
        $stmt = $pdo->prepare("UPDATE articles SET title=?, content=?, author=? WHERE id=?");
        $stmt->execute([$title, $content, $author, $id]);
        header("Location: index.php"); exit;
    } else {
        $error = "Të gjitha fushat janë të detyrueshme.";
    }
}
?>
<!DOCTYPE html>
<html lang="sq">
<head>
<meta charset="UTF-8">
<title>Ndrysho Lajm</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Ndrysho Lajmin</h2>
<?php if (!empty($error)): ?><div style="color:#b91c1c;"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<form method="post">
<label>Titulli:</label>
<input type="text" name="title" value="<?= htmlspecialchars($r['title']) ?>" required>

<label>Përmbajtja:</label>
<textarea name="content" rows="5" required><?= htmlspecialchars($r['content']) ?></textarea>

<label>Autori:</label>
<input type="text" name="author" value="<?= htmlspecialchars($r['author']) ?>" required>

<input type="submit" value="Përditëso">
</form>
<a href="index.php">⬅️ Kthehu</a>
</div>
</body>
</html>
